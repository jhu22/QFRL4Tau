
import torch.nn as nn
from torch.utils.data import Dataset

import sys
sys.path.append('..')
import os
import pandas as pd
from utils import str2int

'''
class DTIDataset(Dataset):
    def __init__(self, root_dir, csv_name, embed_prot=len(VOCAB_PROTEIN), embed_lig=len(VOCAB_LIGAND_ISO), is_Gram = False):
        super(DTIDataset).__init__()
        self.embed_lig = nn.Embedding(embed_lig, 16, padding_idx=0)
        self.embed_prot = nn.Embedding(embed_prot, 16, padding_idx=0)
        self.is_Gram = is_Gram
        self.path = os.path.join(root_dir, csv_name)
        self.data = pd.read_csv(self.path)
        self.embed_drug = nn.Embedding(embed_lig, embed_lig, padding_idx=0)
        self.embed_target = nn.Embedding(embed_prot, embed_prot, padding_idx=0)

    def __getitem__(self, idx):
        ligand , protein, label =  self.data.iloc[idx,]['smiles'], self.data.iloc[idx,]['sequence'], self.data.iloc[idx,]['label']
        ligand, protein, label = str2int(ligand, protein, label)
        if self.is_Gram:
            ligand = Gram(self.embed_lig(ligand))
            protein = Gram(self.embed_prot(protein))
        return ligand, protein, label
    
    def __len__(self):
        return len(self.data)
'''


class DTIDataset(Dataset):
    def __init__(self,root_dir, csv_name):
        super(DTIDataset).__init__()
        self.path = os.path.join(root_dir, csv_name)
        self.data = pd.read_csv(self.path)

    def __getitem__(self,idx):
        ligand , protein, label =  self.data.iloc[idx,]['smiles'], self.data.iloc[idx,]['sequence'], self.data.iloc[idx,]['label']
        ligand, protein, label = str2int(ligand, protein, label)
        return ligand, protein, label

    def __len__(self):
        return len(self.data)





'''
def get_data(data):
    drug, target = data['smiles'], data['sequence']
    drugint = [VOCAB_LIGAND_ISO[s] for s in drug]
    targetint = [VOCAB_PROTEIN[s] for s in target]

    if len(drugint) < 128:
        drugint = np.pad(drugint, (0, 128 - len(drugint)))
    else:
        drugint = drugint[:128]

    if len(targetint) < 512:
        targetint = np.pad(targetint, (0, 512 - len(targetint)))
    else:
        targetint = targetint[:512]

    drugint, targetint = torch.tensor(drugint, dtype=torch.long), torch.tensor(targetint, dtype=torch.long)

    return drugint, targetint


class ClassicalPre(nn.Module):
    def __init__(self, embedding_num_drug=embedding_num_drug, embedding_dim_drug=dim_embed):
        super().__init__()
        self.embed_drug = nn.Embedding(embedding_num_drug, embedding_dim_drug, padding_idx=0)
        self.embed_target = nn.Embedding(embedding_num_target, embedding_dim_target, padding_idx=0)

    def datapre(self, data):
        drugint, targetint = get_data(data)
        d = self.embed_drug(drugint)
        t = self.embed_target(targetint)
        Gram_d = d.T @ d
        Gram_t = t.T @ t
        C_input_d = Gram_d.view(-1, hyber_para, hyber_para)
        C_input_t = Gram_t.view(-1, hyber_para, hyber_para)
        return C_input_d, C_input_t  # 都是[1,16,16]

    def forward(self, data):  # data是一整条数据
        drug_input, target_input = self.datapre(data)
        return drug_input, target_input  # 都是[1,16,16]

'''
