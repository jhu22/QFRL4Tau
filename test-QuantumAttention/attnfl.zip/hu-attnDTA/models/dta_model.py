import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
sys.path.append('..')
from network import make_model



embedding_num_drug = 64  # 字典序
embedding_num_target = 25  # 字典序
embedding_dim_drug = 16  # 2^4
embedding_dim_target = 16  # 2^4
hyber_para = 16  # 2^4
dim_embed = hyber_para



def Gram_batch(tensor):
    # 计算共轭转置
    tensor_conjugate_transpose = torch.conj(tensor.transpose(1, 2))
    # 执行矩阵乘法
    result = torch.matmul(tensor_conjugate_transpose, tensor)
    return result
    


class ClassicalPre(nn.Module):
    def __init__(self, embedding_num_drug=embedding_num_drug, embedding_dim_drug=dim_embed):
        super().__init__()
        self.embed_drug = nn.Embedding(embedding_num_drug, embedding_dim_drug, padding_idx=0)
        self.embed_target = nn.Embedding(embedding_num_target, embedding_dim_target, padding_idx=0)

    def datapre(self, protein, ligand):
        d = self.embed_drug(ligand)
        t = self.embed_target(protein)
        Gram_d = Gram_batch(d)
        Gram_t = Gram_batch(t)
        C_input_d = Gram_d.view(-1, hyber_para, hyber_para)
        C_input_t = Gram_t.view(-1, hyber_para, hyber_para)
        return C_input_t, C_input_d  # 都是[_,16,16]

    def forward(self, protein, ligand):  # data是一整条数据
        t_input, d_input = self.datapre(protein, ligand)
        return t_input, d_input  # 都是[_,16,16]



class attnDTA(nn.Module):
    def __init__(self):
        super(attnDTA, self).__init__()
        self.data_pre = ClassicalPre()
        self.att = make_model(1)
        self.FC1 = nn.Linear(512, 256)
        self.FC2 = nn.Linear(256, 128)
        self.FC3 = nn.Linear(128, 1)

    def forward(self, protein, ligand):
        t_input, d_input = self.data_pre(protein, ligand)
        drug_input = self.att(d_input)
        target_input = self.att(t_input)
        linear_input = torch.cat([drug_input, target_input], dim=0).view(32,-1)
        out = F.leaky_relu(self.FC1(linear_input))
        out = F.leaky_relu(self.FC2(out))
        output = F.leaky_relu(self.FC3(out))

        return output
