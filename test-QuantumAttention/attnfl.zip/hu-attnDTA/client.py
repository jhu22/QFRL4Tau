import warnings
#import numpy as np
import flwr as fl
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F

#from matplotlib import pyplot as plt
import torchvision.datasets as datasets
import torchvision.transforms as transforms
#from torchvision.transforms import Compose, Normalize, ToTensor
from torch.utils.data import DataLoader
#from torchvision.utils import make_grid
from tqdm import tqdm

from utils import *
from dataloader import DTIDataset
# from models import DeepDTA
from network import make_model


warnings.filterwarnings("ignore", category=UserWarning)
DEVICE = torch.device("cpu")
#("cuda:0" if torch.cuda.is_available() else "cpu")

root_dir = r'./data/'
train_dataset_name = 'training_dataset.csv'
test_dataset_name = 'test_dataset.csv'
val_dataset_name = 'validation_dataset.csv'
TRAIN_PATH = './logs/DTA_result/train/epoch{} train_loss_min_{}_dict_dta.pth'
TEST_PATH = './logs/DTA_result/test/epoch{}_dict_dta.pth'
BEST_RESULT_PATH = './logs/DTA_result/best_result_dict_dta.pth'

train_dataset = DTIDataset(root_dir=root_dir, csv_name=train_dataset_name)
train_dataloader = DataLoader(train_dataset, batch_size=32,shuffle=True,drop_last=True)

test_dataset = DTIDataset(root_dir=root_dir, csv_name=test_dataset_name)
test_dataloader = DataLoader(test_dataset, batch_size=32,shuffle=True,drop_last=True)

val_dataset = DTIDataset(root_dir=root_dir, csv_name=val_dataset_name)
val_dataloader = DataLoader(val_dataset, batch_size=32,shuffle=True,drop_last=True)


embedding_num_drug = 64  # 字典序
embedding_num_target = 25  # 字典序
embedding_dim_drug = 16  # 2^4
embedding_dim_target = 16  # 2^4
hyber_para = 16  # 2^4
dim_embed = hyber_para


def Gram_batch(tensor):
    # 计算共轭转置
    tensor_conjugate_transpose = torch.conj(tensor.transpose(1, 2))
    # 执行矩阵乘法
    result = torch.matmul(tensor_conjugate_transpose, tensor)
    return result



class ClassicalPre(nn.Module):
    def __init__(self, embedding_num_drug=embedding_num_drug, embedding_dim_drug=dim_embed):
        super().__init__()
        self.embed_drug = nn.Embedding(embedding_num_drug, embedding_dim_drug, padding_idx=0)
        self.embed_target = nn.Embedding(embedding_num_target, embedding_dim_target, padding_idx=0)

    def datapre(self, protein, ligand):
        d = self.embed_drug(ligand)
        t = self.embed_target(protein)
        Gram_d = Gram_batch(d)
        Gram_t = Gram_batch(t)
        C_input_d = Gram_d.view(-1, hyber_para, hyber_para)
        C_input_t = Gram_t.view(-1, hyber_para, hyber_para)
        return C_input_t, C_input_d  # 都是[_,16,16]

    def forward(self, protein, ligand):  # data是一整条数据
        t_input, d_input = self.datapre(protein, ligand)
        return t_input, d_input  # 都是[_,16,16]



class attnDTA(nn.Module):
    def __init__(self):
        super(attnDTA, self).__init__()
        self.data_pre = ClassicalPre()
        self.att = make_model(1)
        self.FC1 = nn.Linear(512, 256)
        self.FC2 = nn.Linear(256, 128)
        self.FC3 = nn.Linear(128, 1)

    def forward(self, protein, ligand):
        t_input, d_input = self.data_pre(protein, ligand)
        drug_input = self.att(d_input)
        target_input = self.att(t_input)
        linear_input = torch.cat([drug_input, target_input], dim=0).view(32,-1)
        out = F.leaky_relu(self.FC1(linear_input))
        out = F.leaky_relu(self.FC2(out))
        output = F.leaky_relu(self.FC3(out))

        return output

net=attnDTA()


trainloader = train_dataloader
testloader = test_dataloader



def train(net, trainloader, epochs):
    """Train the model on the training set."""
    criterion = nn.MSELoss() # torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(net.parameters(),lr=0.001) #torch.optim.SGD(net.parameters(), lr=0.001, momentum=0.9)
    for _ in range(epochs):
        for data in tqdm(trainloader):
            ligand, protein, labels = data
            optimizer.zero_grad()
            criterion(net(protein.to(DEVICE), ligand.to(DEVICE)), labels.to(DEVICE)).backward()
            optimizer.step()

def test(net, val_loader):
    """Validate the model on the test set."""
    # criterion = torch.nn.CrossEntropyLoss()
    pred_list = []
    label_list = []
    rmse_list = []
    # correct, loss = 0, 0.0
    with torch.no_grad():
        for data in tqdm(val_loader):
            ligand, protein, labels = data
            outputs = net(protein.to(DEVICE), ligand.to(DEVICE))
            labels = labels.to(DEVICE)
            rmse_list.append(get_rmse(labels, outputs))
            pred_list.append(outputs)
            label_list.append(labels)
            # loss += criterion(outputs, labels).item()
            # correct += (torch.max(outputs.data, 1)[1] == labels).sum().item()
    # accuracy = correct / len(testloader.dataset)
    rmse = sum(rmse_list) / len(rmse_list)
    pred = np.concatenate(pred_list).reshape(-1)
    label = np.concatenate(label_list).reshape(-1)
    accuracy = np.corrcoef(pred, label)[0, 1]
    return rmse, accuracy


class FlowerClient(fl.client.NumPyClient):
    def get_parameters(self, config):#config？？
        return [val.cpu().numpy() for _, val in net.state_dict().items()]

    def set_parameters(self, parameters):
        params_dict = zip(net.state_dict().keys(), parameters)
        state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
        net.load_state_dict(state_dict, strict=True)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        train(net, trainloader, epochs=1)
        return self.get_parameters(config={}), len(trainloader.dataset), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        loss, accuracy = test(net, testloader)
        return loss, len(testloader.dataset), {"accuracy": accuracy}



fl.client.start_numpy_client(
    server_address="127.0.0.1:8080",
    client=FlowerClient(),
)
